# fit gives different reply to you
print("Let's talk! Enter 'quit' to exit...")

while True:
    user = input("You: ").lower()  # Convert input to lowercase for case-insensitive matching

    if user == 'quit':
        print("Bot: Goodbye! Have a great day!")
        break  
        
    
    # Conditional responses based on user input
    if "hello" in user or "hi" in user:
        print("Bot: Hello! How can I assist you today?")
    elif "how are you" in user:
        print("Bot: I'm just a bot, but I'm doing well! How about you?")
    elif "your name" in user:
        print("Bot: I am a simple chatbot. You can call me Bot!")
    elif "help" in user:
        print("Bot: Sure! What do you need help with?")
    elif "weather" in user:
        print("Bot: I can't check the weather, but I hope it's nice outside!")
    elif "thank you" in user or "thanks" in user:
        print("Bot: You're welcome! I'm here to help.")
    else:
        print("Bot: Hmm, I don't understand that. Can you ask something else?")

#for simple chat boot it will give same reply as you
"""print("Let's talk! Enter 'quit' to exit...")

while True:
    user = input("You: ")
    print(f"Bot: {user}")

    if user == 'quit':
        break        """