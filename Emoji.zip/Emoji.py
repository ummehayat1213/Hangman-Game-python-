# This code print the emojis in one line 
#import demoji

#text = """ I will be your Secret santa this year🎅🏻 , the party I'm hosting for you is going to be lit🔥, Thank you🫂! Have Fun till than you🃏 🤽🏻‍♂️👨🏻‍🚀 """
#emoji_dict_text = demoji.findall(text)
#print("Emojis in text:", emoji_dict_text)

#emoji_list = """🥰🤩😵😵‍💫👏🏼🤲🏻👩🏼‍❤️‍💋‍👨🏼🥺😳🤯😈👀"""
#emoji_dict_list = demoji.findall(emoji_list)
#print("Emojis in emoji_list:", emoji_dict_list)"""""

#This code print the all emojis one by one
import demoji

text = """ I will be your Secret santa this year🎅🏻 , the party I'm hosting for you is going to be lit🔥, Thank you🫂! Have Fun till than you🃏 🤽🏻‍♂️👨🏻‍🚀 """
emoji_dict_text = demoji.findall(text)

# Looping through each emoji and its description in the text
print("Emojis in text:")
for emoji, description in emoji_dict_text.items():
    print(f"{emoji}: {description}")

emoji_list = """🥰🤩😵😵‍💫👏🏼🤲🏻👩🏼‍❤️‍💋‍👨🏼🥺😳🤯😈👀"""
emoji_dict_list = demoji.findall(emoji_list)

# Looping through each emoji and its description in the emoji list
print("\nEmojis in emoji_list:")
for emoji, description in emoji_dict_list.items():
    print(f"{emoji}: {description}")


